/**
 * worker/queue-consumer.ts
 *
 * Processes async sync jobs from the `sync-queue` Cloudflare Queue.
 * Handles:
 *  - vehicle_sync: push sold/updated vehicle data to Wayne Reeves DMS
 *  - expense_sync: create QuickBooks expense for a service record
 *  - quickbooks_auth_refresh: refresh an expiring QB access token
 */

import type { MessageBatch } from '@cloudflare/workers-types';
import type { Env } from '../src/index';

type QueueMessage =
  | { type: 'vehicle_sync'; action: 'sold' | 'update'; vehicleId: string; timestamp: string }
  | { type: 'expense_sync'; serviceId: string; vehicleId: string; amount: number; timestamp: string }
  | { type: 'quickbooks_auth_refresh'; timestamp: string };

export default {
  async queue(batch: MessageBatch<QueueMessage>, env: Env): Promise<void> {
    for (const message of batch.messages) {
      try {
        await processSyncMessage(message.body, env);
        message.ack();
      } catch (error) {
        console.error('Queue processing error:', error);
        message.retry();
      }
    }
  },
};

async function processSyncMessage(msg: QueueMessage, env: Env): Promise<void> {
  switch (msg.type) {
    case 'vehicle_sync':
      await syncVehicleToExternalSystems(msg, env);
      break;
    case 'expense_sync':
      await syncExpenseToQuickBooks(msg, env);
      break;
    case 'quickbooks_auth_refresh':
      await refreshQuickBooksToken(env);
      break;
    default:
      console.warn('Unknown sync message type:', (msg as { type: string }).type);
  }
}

async function syncVehicleToExternalSystems(
  msg: Extract<QueueMessage, { type: 'vehicle_sync' }>,
  env: Env
): Promise<void> {
  if (!env.WAYNE_REEVES_API_KEY || !env.WAYNE_REEVES_API_URL) return;

  // Look up the vehicle from the CarLotAgent
  const id = env.CARLOT_AGENT.idFromName('main');
  const stub = env.CARLOT_AGENT.get(id);
  const vehicleResp = await stub.fetch(`http://internal/api/vehicles/${msg.vehicleId}`);

  if (!vehicleResp.ok) {
    throw new Error(`CarLotAgent vehicle lookup failed: ${vehicleResp.status}`);
  }

  const vehicle = (await vehicleResp.json()) as Record<string, unknown>;

  if (!vehicle.externaldmsid) {
    console.warn('Vehicle missing externaldmsid; skipping Wayne Reeves sync', msg.vehicleId);
    return;
  }

  const baseUrl = String(env.WAYNE_REEVES_API_URL).replace(/\/+$/, '');

  if (msg.action === 'sold') {
    const res = await fetch(`${baseUrl}/inventory/${vehicle.externaldmsid}/sold`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${env.WAYNE_REEVES_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ saleDate: vehicle.saledate, salePrice: vehicle.saleprice }),
    });
    if (!res.ok) throw new Error(`Wayne Reeves sold API error: ${res.status}`);
  } else {
    const res = await fetch(`${baseUrl}/inventory/${vehicle.externaldmsid}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${env.WAYNE_REEVES_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        mileage: vehicle.mileage,
        location: vehicle.location,
        status: vehicle.status,
      }),
    });
    if (!res.ok) throw new Error(`Wayne Reeves update API error: ${res.status}`);
  }

  console.log(`Vehicle ${msg.vehicleId} synced to Wayne Reeves`);
}

async function syncExpenseToQuickBooks(
  msg: Extract<QueueMessage, { type: 'expense_sync' }>,
  env: Env
): Promise<void> {
  if (!env.QUICKBOOKS_REALM_ID) return;

  const accessToken = await env.INTEGRATIONS_KV.get('quickbooks_access_token');
  if (!accessToken) {
    console.error('QuickBooks not authenticated — skipping expense sync');
    return;
  }

  const expense = {
    PaymentType: 'Cash',
    AccountRef: { value: '35' }, // TODO: map to real QBO account ID
    Line: [
      {
        Amount: msg.amount,
        DetailType: 'AccountBasedExpenseLineDetail',
        AccountBasedExpenseLineDetail: { AccountRef: { value: '35' } },
        Description: `Service expense — service ID ${msg.serviceId}`,
      },
    ],
    TxnDate: new Date().toISOString().split('T')[0],
  };

  const response = await fetch(
    `https://quickbooks.api.intuit.com/v3/company/${env.QUICKBOOKS_REALM_ID}/purchase`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(expense),
    }
  );

  if (!response.ok) {
    throw new Error(`QuickBooks API error: ${response.status} ${await response.text()}`);
  }

  console.log(`Expense ${msg.serviceId} synced to QuickBooks`);
}

async function refreshQuickBooksToken(env: Env): Promise<void> {
  if (!env.QUICKBOOKS_CLIENT_ID || !env.QUICKBOOKS_CLIENT_SECRET) return;

  const refreshToken = await env.INTEGRATIONS_KV.get('quickbooks_refresh_token');
  if (!refreshToken) return;

  try {
    const basicAuth = btoa(`${env.QUICKBOOKS_CLIENT_ID}:${env.QUICKBOOKS_CLIENT_SECRET}`);
    const response = await fetch('https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Basic ${basicAuth}`,
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
      }),
    });

    if (!response.ok) {
      throw new Error(`Token refresh failed: ${response.status} ${await response.text()}`);
    }

    const tokens = (await response.json()) as {
      access_token: string;
      refresh_token: string;
      expires_in: number;
    };

    await env.INTEGRATIONS_KV.put('quickbooks_access_token', tokens.access_token, {
      expirationTtl: tokens.expires_in ?? 3600,
    });
    await env.INTEGRATIONS_KV.put('quickbooks_refresh_token', tokens.refresh_token);

    console.log('QuickBooks token refreshed successfully');
  } catch (error) {
    // Do not re-throw — bad credentials shouldn't cause infinite queue retries
    console.error('Token refresh error:', error);
  }
}
