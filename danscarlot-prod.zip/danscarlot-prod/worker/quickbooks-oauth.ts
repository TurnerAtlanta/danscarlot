/**
 * worker/quickbooks-oauth.ts
 *
 * QuickBooks Online OAuth 2.0 flow.
 * Handles authorize → callback → token storage → disconnect.
 *
 * Secrets required (set via `wrangler secret put`):
 *   QUICKBOOKS_CLIENT_ID
 *   QUICKBOOKS_CLIENT_SECRET
 */

import type { Env } from '../src/index';

const QB_AUTH_URL = 'https://appcenter.intuit.com/connect/oauth2';
const QB_TOKEN_URL = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';

/** Step 1: Redirect the user to Intuit's auth page */
export async function handleQuickBooksAuthorize(
  request: Request,
  env: Env
): Promise<Response> {
  if (!env.QUICKBOOKS_CLIENT_ID) {
    return Response.json({ error: 'QuickBooks client ID not configured' }, { status: 500 });
  }

  const url = new URL(request.url);
  const redirectUri = `${url.protocol}//${url.host}/api/integrations/quickbooks/callback`;

  // CSRF state token — stored in KV with 10-min expiry
  const state = crypto.randomUUID();
  await env.INTEGRATIONS_KV.put(`qb_oauth_state:${state}`, 'pending', { expirationTtl: 600 });

  const authUrl = new URL(QB_AUTH_URL);
  authUrl.searchParams.set('client_id', env.QUICKBOOKS_CLIENT_ID);
  authUrl.searchParams.set('scope', 'com.intuit.quickbooks.accounting');
  authUrl.searchParams.set('redirect_uri', redirectUri);
  authUrl.searchParams.set('response_type', 'code');
  authUrl.searchParams.set('state', state);

  return Response.redirect(authUrl.toString(), 302);
}

/** Step 2: Handle the OAuth callback from Intuit */
export async function handleQuickBooksCallback(
  request: Request,
  env: Env
): Promise<Response> {
  if (!env.QUICKBOOKS_CLIENT_ID || !env.QUICKBOOKS_CLIENT_SECRET) {
    return new Response('QuickBooks credentials not configured', { status: 500 });
  }

  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const realmId = url.searchParams.get('realmId');
  const error = url.searchParams.get('error');

  if (error) return new Response(`QuickBooks auth failed: ${error}`, { status: 400 });
  if (!code || !state || !realmId) return new Response('Missing required params', { status: 400 });

  // Verify CSRF state
  const storedState = await env.INTEGRATIONS_KV.get(`qb_oauth_state:${state}`);
  if (!storedState) return new Response('Invalid state — possible CSRF', { status: 400 });

  // Exchange code for tokens
  const redirectUri = `${url.protocol}//${url.host}/api/integrations/quickbooks/callback`;
  const basicAuth = btoa(`${env.QUICKBOOKS_CLIENT_ID}:${env.QUICKBOOKS_CLIENT_SECRET}`);

  const tokenRes = await fetch(QB_TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${basicAuth}`,
    },
    body: new URLSearchParams({ grant_type: 'authorization_code', code, redirect_uri: redirectUri }),
  });

  if (!tokenRes.ok) {
    const errText = await tokenRes.text();
    console.error('QB token exchange failed:', errText);
    return new Response(`Token exchange failed: ${errText}`, { status: 400 });
  }

  const tokens = (await tokenRes.json()) as {
    access_token: string;
    refresh_token: string;
    expires_in: number;
  };

  // Store in KV
  await Promise.all([
    env.INTEGRATIONS_KV.put('quickbooks_access_token', tokens.access_token, {
      expirationTtl: tokens.expires_in ?? 3600,
    }),
    env.INTEGRATIONS_KV.put('quickbooks_refresh_token', tokens.refresh_token),
    env.INTEGRATIONS_KV.put('quickbooks_realm_id', realmId),
    env.INTEGRATIONS_KV.put('quickbooks_connected_at', new Date().toISOString()),
    env.INTEGRATIONS_KV.delete(`qb_oauth_state:${state}`),
  ]);

  // Success page — auto-closes popup and notifies opener
  return new Response(
    `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>QuickBooks Connected</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f5f5f7; }
    .card { background: #fff; padding: 40px; border-radius: 20px; text-align: center; box-shadow: 0 4px 30px rgba(0,0,0,.08); max-width: 360px; }
    h1 { color: #2ca01c; margin: 0 0 12px; font-size: 22px; }
    p { color: #555; margin: 0 0 8px; font-size: 15px; }
    button { margin-top: 24px; padding: 12px 28px; background: #007AFF; color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 600; cursor: pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h1>✅ QuickBooks Connected!</h1>
    <p>Your QuickBooks account is now connected.</p>
    <p>Sales and expenses will sync automatically.</p>
    <button onclick="window.close()">Close Window</button>
  </div>
  <script>
    setTimeout(() => {
      if (window.opener) {
        window.opener.postMessage({ type: 'quickbooks_connected' }, '*');
        window.close();
      }
    }, 2000);
  </script>
</body>
</html>`,
    { headers: { 'Content-Type': 'text/html' } }
  );
}

/** Disconnect / revoke QuickBooks tokens */
export async function handleQuickBooksDisconnect(env: Env): Promise<Response> {
  await Promise.all([
    env.INTEGRATIONS_KV.delete('quickbooks_access_token'),
    env.INTEGRATIONS_KV.delete('quickbooks_refresh_token'),
    env.INTEGRATIONS_KV.delete('quickbooks_realm_id'),
    env.INTEGRATIONS_KV.delete('quickbooks_connected_at'),
  ]);
  return Response.json({ success: true, message: 'QuickBooks disconnected' });
}
