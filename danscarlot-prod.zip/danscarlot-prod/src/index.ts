/**
 * src/index.ts — Dan's Car Lot · Main Cloudflare Worker + CarLotAgent Durable Object
 *
 * Fixes applied vs. original:
 *  - Correct `import { Hono }` (named export)
 *  - Fixed `let data` variable declaration (was `let WebSocketMessage`)
 *  - Removed duplicate `export default` (queue handler merged into single export)
 *  - `this.ctx.acceptWebSocket()` used in place of `connection.accept()`
 *  - API routes unified: `/api/vehicles` (worker) → client `api.ts` updated to match
 *  - Security headers added to all responses
 *  - QuickBooks OAuth import path corrected
 *  - Env bindings use consistent camelCase names matching wrangler.jsonc
 */

import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { secureHeaders } from 'hono/secure-headers';
import { Agent, routeAgentRequest } from 'agents';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface Env {
  CARLOT_AGENT: DurableObjectNamespace<CarLotAgent>;
  INTEGRATIONS_KV: KVNamespace;
  AUTH_KV: KVNamespace;
  SYNC_QUEUE: Queue<QueueMessage>;
  ASSETS: Fetcher;
  // Secrets (set via `wrangler secret put`)
  WAYNE_REEVES_API_KEY?: string;
  WAYNE_REEVES_API_URL?: string;
  QUICKBOOKS_CLIENT_ID?: string;
  QUICKBOOKS_CLIENT_SECRET?: string;
  QUICKBOOKS_REALM_ID?: string;
  CARGURUS_API_KEY?: string;
  TRUECAR_DEALER_ID?: string;
  KBB_DEALER_ID?: string;
}

type QueueMessage =
  | { type: 'vehicle_sync'; action: 'sold' | 'update'; vehicleId: string; timestamp: string }
  | { type: 'expense_sync'; serviceId: string; vehicleId: string; amount: number; timestamp: string };

export interface Vehicle {
  id: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  purchaseprice: number;
  purchasedate: string;
  saleprice: number | null;
  saledate: string | null;
  status: string;
  location: string;
  mileage: number;
  color: string;
  bodystyle: string;
  transmission: string;
  fueltype: string;
  description: string;
  features: string;
  images: string;
  createdat: string;
  updatedat?: string;
  publishtowebsite: number;
  publishtothirdparty: number;
  externaldmsid?: string;
  externaldmssource?: string;
  quickbooksinvoiceid?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  assignee: string;
  duedate: string;
  status: string;
  createdby: string;
  createdat: string;
  updatedat?: string;
}

export interface Service {
  id: string;
  vehicleid: string;
  servicetype: string;
  description: string;
  cost: number;
  servicedate: string;
  createdat: string;
}

interface Comment {
  id: string;
  entitytype: string;
  entityid: string;
  username: string;
  comment: string;
  createdat: string;
}

interface WebSocketMessage {
  type: string;
  payload?: unknown;
  source?: string;
}

// ============================================================================
// CARLOT AGENT (DURABLE OBJECT)
// ============================================================================

export class CarLotAgent extends Agent<Env> {
  /**
   * Called when a WebSocket client connects.
   * Uses the Hibernatable WebSocket API via this.ctx.acceptWebSocket().
   */
  async onConnect(connection: WebSocket): Promise<void> {
    // DO NOT call connection.accept() — Agent base class handles this via
    // the Hibernatable WebSocket API (this.ctx.acceptWebSocket internally).

    const tasks = await this.sql<Task>`SELECT * FROM tasks ORDER BY createdat DESC LIMIT 100`;
    const vehicles = await this.sql<Vehicle>`SELECT * FROM vehicles ORDER BY createdat DESC LIMIT 100`;

    connection.send(
      JSON.stringify({
        type: 'state',
        tasks: Array.from(tasks),
        vehicles: Array.from(vehicles),
      })
    );
  }

  async onMessage(connection: WebSocket, message: string | ArrayBuffer): Promise<void> {
    if (typeof message !== 'string') {
      console.error('Received non-string message');
      return;
    }

    let data: WebSocketMessage;
    try {
      data = JSON.parse(message) as WebSocketMessage;
    } catch (err) {
      console.error('Invalid JSON message received:', err);
      return;
    }

    switch (data.type) {
      case 'task_update':
        await this.handleTaskUpdate(data.payload);
        this.broadcast(JSON.stringify(data));
        break;
      case 'inventory_update':
        await this.handleInventoryUpdate(data.payload);
        this.broadcast(JSON.stringify(data));
        break;
      case 'comment_add':
        await this.handleCommentAdd(data.payload);
        this.broadcast(JSON.stringify(data));
        break;
      default:
        console.warn('Unknown message type:', data.type);
    }
  }

  // ---- Private helpers ----

  private async handleTaskUpdate(payload: unknown): Promise<void> {
    const p = payload as Task & { dueDate?: string; createdBy?: string };
    await this.sql`
      INSERT INTO tasks (id, title, description, assignee, duedate, status, createdby, createdat)
      VALUES (${p.id}, ${p.title}, ${p.description}, ${p.assignee}, ${p.dueDate ?? p.duedate}, ${p.status}, ${p.createdBy ?? p.createdby}, ${new Date().toISOString()})
      ON CONFLICT(id) DO UPDATE SET
        title       = ${p.title},
        description = ${p.description},
        assignee    = ${p.assignee},
        duedate     = ${p.dueDate ?? p.duedate},
        status      = ${p.status},
        updatedat   = ${new Date().toISOString()}
    `;
  }

  private async handleInventoryUpdate(payload: unknown): Promise<void> {
    const p = payload as Record<string, unknown>;
    await this.sql`
      INSERT INTO vehicles (
        id, vin, make, model, year, purchaseprice, purchasedate, saleprice, saledate,
        status, location, mileage, color, bodystyle, transmission, fueltype,
        description, features, images, createdat, publishtowebsite, publishtothirdparty
      ) VALUES (
        ${p.id}, ${p.vin}, ${p.make}, ${p.model}, ${p.year},
        ${p.purchasePrice}, ${p.purchaseDate}, ${p.salePrice ?? null}, ${p.saleDate ?? null},
        ${p.status}, ${p.location}, ${p.mileage ?? 0}, ${p.color ?? ''}, ${p.bodyStyle ?? ''},
        ${p.transmission ?? ''}, ${p.fuelType ?? ''}, ${p.description ?? ''}, ${p.features ?? ''},
        ${p.images ?? ''}, ${new Date().toISOString()},
        ${p.publishToWebsite !== false ? 1 : 0}, ${p.publishToThirdParty !== false ? 1 : 0}
      )
      ON CONFLICT(id) DO UPDATE SET
        make                = ${p.make},
        model               = ${p.model},
        year                = ${p.year},
        purchaseprice       = ${p.purchasePrice},
        saleprice           = ${p.salePrice ?? null},
        saledate            = ${p.saleDate ?? null},
        status              = ${p.status},
        location            = ${p.location},
        mileage             = ${p.mileage ?? 0},
        color               = ${p.color ?? ''},
        bodystyle           = ${p.bodyStyle ?? ''},
        transmission        = ${p.transmission ?? ''},
        fueltype            = ${p.fuelType ?? ''},
        description         = ${p.description ?? ''},
        features            = ${p.features ?? ''},
        images              = ${p.images ?? ''},
        publishtowebsite    = ${p.publishToWebsite !== false ? 1 : 0},
        publishtothirdparty = ${p.publishToThirdParty !== false ? 1 : 0},
        updatedat           = ${new Date().toISOString()}
    `;

    // Enqueue sync job when vehicle is marked sold
    if (p.saleDate && this.env.SYNC_QUEUE) {
      try {
        await this.env.SYNC_QUEUE.send({
          type: 'vehicle_sync',
          action: 'sold',
          vehicleId: p.id as string,
          timestamp: new Date().toISOString(),
        });
      } catch (error) {
        console.error('Error queuing vehicle sync:', error);
      }
    }
  }

  private async handleCommentAdd(payload: unknown): Promise<void> {
    const p = payload as Comment & { entityType?: string; entityId?: string; userName?: string };
    await this.sql`
      INSERT INTO comments (id, entitytype, entityid, username, comment, createdat)
      VALUES (
        ${p.id},
        ${p.entityType ?? p.entitytype},
        ${p.entityId ?? p.entityid},
        ${p.userName ?? p.username},
        ${p.comment},
        ${new Date().toISOString()}
      )
    `;
  }

  /** Broadcast a message to all connected WebSocket clients */
  private broadcast(message: string): void {
    for (const conn of this.ctx.getWebSockets()) {
      try {
        conn.send(message);
      } catch (error) {
        console.error('Error broadcasting to connection:', error);
      }
    }
  }

  // ---- HTTP Request Handler ----

  async onRequest(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method;

    // ---- Tasks ----
    if (pathname === '/api/tasks' && method === 'GET') {
      const tasks = await this.sql<Task>`SELECT * FROM tasks ORDER BY createdat DESC`;
      return Response.json(Array.from(tasks));
    }

    // ---- Vehicles (internal — full data) ----
    if (pathname === '/api/vehicles' && method === 'GET') {
      const vehicles = await this.sql<Vehicle>`SELECT * FROM vehicles ORDER BY createdat DESC`;
      return Response.json(Array.from(vehicles));
    }

    if (pathname === '/api/vehicles' && method === 'POST') {
      const payload = (await request.json()) as Record<string, unknown>;
      await this.handleInventoryUpdate(payload);
      return Response.json({ success: true }, { status: 201 });
    }

    if (pathname.match(/^\/api\/vehicles\/[^/]+$/) && method === 'GET') {
      const vehicleId = pathname.split('/').pop();
      const rows = await this.sql<Vehicle>`SELECT * FROM vehicles WHERE id = ${vehicleId} LIMIT 1`;
      const result = Array.from(rows);
      if (result.length === 0) return Response.json({ error: 'Vehicle not found' }, { status: 404 });
      return Response.json(result[0]);
    }

    if (pathname.match(/^\/api\/vehicles\/[^/]+$/) && method === 'PUT') {
      const payload = (await request.json()) as Record<string, unknown>;
      await this.handleInventoryUpdate(payload);
      return Response.json({ success: true });
    }

    if (pathname.match(/^\/api\/vehicles\/[^/]+$/) && method === 'DELETE') {
      const vehicleId = pathname.split('/').pop();
      await this.sql`DELETE FROM vehicles WHERE id = ${vehicleId}`;
      return Response.json({ success: true });
    }

    // ---- Public inventory feed (customer-facing, no auth required) ----
    if (pathname === '/api/public/inventory' && method === 'GET') {
      const vehicles = await this.sql<Partial<Vehicle>>`
        SELECT id, vin, make, model, year, saleprice AS price, mileage, color, bodystyle,
               transmission, fueltype, description, features, images, location
        FROM vehicles
        WHERE status = 'available' AND publishtowebsite = 1
        ORDER BY createdat DESC
      `;
      return Response.json(Array.from(vehicles), {
        headers: {
          'Cache-Control': 'public, max-age=300',
          'Access-Control-Allow-Origin': '*',
        },
      });
    }

    if (pathname.match(/^\/api\/public\/vehicle\/[^/]+$/) && method === 'GET') {
      const vehicleId = pathname.split('/').pop();
      const rows = await this.sql<Partial<Vehicle>>`
        SELECT id, vin, make, model, year, saleprice AS price, mileage, color, bodystyle,
               transmission, fueltype, description, features, images, location
        FROM vehicles
        WHERE id = ${vehicleId} AND status = 'available' AND publishtowebsite = 1
        LIMIT 1
      `;
      const result = Array.from(rows);
      if (result.length === 0) return Response.json({ error: 'Vehicle not found' }, { status: 404 });
      return Response.json(result[0], {
        headers: { 'Cache-Control': 'public, max-age=300', 'Access-Control-Allow-Origin': '*' },
      });
    }

    // ---- Services ----
    if (pathname === '/api/services' && method === 'GET') {
      const vehicleId = url.searchParams.get('vehicleId');
      const services = await this.sql<Service>`
        SELECT * FROM services WHERE vehicleid = ${vehicleId} ORDER BY servicedate DESC
      `;
      return Response.json(Array.from(services));
    }

    if (pathname === '/api/services' && method === 'POST') {
      const payload = (await request.json()) as Service & {
        vehicleId?: string; serviceType?: string; serviceDate?: string;
      };
      await this.sql`
        INSERT INTO services (id, vehicleid, servicetype, description, cost, servicedate, createdat)
        VALUES (
          ${payload.id},
          ${payload.vehicleId ?? payload.vehicleid},
          ${payload.serviceType ?? payload.servicetype},
          ${payload.description},
          ${payload.cost},
          ${payload.serviceDate ?? payload.servicedate},
          ${new Date().toISOString()}
        )
      `;
      this.broadcast(JSON.stringify({ type: 'service_add', payload }));

      if (this.env.SYNC_QUEUE) {
        await this.env.SYNC_QUEUE.send({
          type: 'expense_sync',
          serviceId: payload.id,
          vehicleId: payload.vehicleId ?? payload.vehicleid,
          amount: payload.cost,
          timestamp: new Date().toISOString(),
        }).catch((err) => console.error('Error queuing expense sync:', err));
      }
      return Response.json({ success: true }, { status: 201 });
    }

    // ---- Analytics ----
    if (pathname === '/api/analytics' && method === 'GET') {
      return Response.json(await this.calculateAnalytics());
    }

    // ---- Comments ----
    if (pathname === '/api/comments' && method === 'GET') {
      const entityType = url.searchParams.get('entityType');
      const entityId = url.searchParams.get('entityId');
      const comments = await this.sql<Comment>`
        SELECT * FROM comments
        WHERE entitytype = ${entityType} AND entityid = ${entityId}
        ORDER BY createdat ASC
      `;
      return Response.json(Array.from(comments));
    }

    return new Response('Not found', { status: 404 });
  }

  private async calculateAnalytics() {
    const vehicles = Array.from(await this.sql<Vehicle>`SELECT * FROM vehicles`);
    const services = Array.from(await this.sql<Service>`SELECT * FROM services`);

    let totalRevenue = 0;
    let totalCost = 0;
    let soldCount = 0;
    let inventoryCount = 0;

    for (const v of vehicles) {
      totalCost += Number(v.purchaseprice) || 0;
      if (v.status === 'sold' && v.saleprice) {
        totalRevenue += Number(v.saleprice);
        soldCount++;
      } else {
        inventoryCount++;
      }
    }
    for (const s of services) {
      totalCost += Number(s.cost) || 0;
    }

    const profit = totalRevenue - totalCost;
    const margin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;

    return {
      totalRevenue,
      totalCost,
      profit,
      margin: Number(margin.toFixed(2)),
      soldCount,
      inventoryCount,
      avgProfitPerVehicle: soldCount > 0 ? Number((profit / soldCount).toFixed(2)) : 0,
    };
  }
}

// ============================================================================
// SECURITY HEADERS HELPER
// ============================================================================

function addSecurityHeaders(response: Response): Response {
  const headers = new Headers(response.headers);
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('X-Frame-Options', 'DENY');
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  headers.set(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' wss: https:;"
  );
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

// ============================================================================
// MAIN HONO APP
// ============================================================================

const app = new Hono<{ Bindings: Env }>();

// CORS — restrict to known origins in production
app.use(
  '*',
  cors({
    origin: ['https://danscarlot.turneratlanta.com', 'http://localhost:5173'],
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  })
);

// Security headers on all responses
app.use('*', secureHeaders());

// ---- QuickBooks OAuth ----
app.get('/api/integrations/quickbooks/authorize', async (c) => {
  const { handleQuickBooksAuthorize } = await import('../worker/quickbooks-oauth');
  return handleQuickBooksAuthorize(c.req.raw, c.env);
});

app.get('/api/integrations/quickbooks/callback', async (c) => {
  const { handleQuickBooksCallback } = await import('../worker/quickbooks-oauth');
  return handleQuickBooksCallback(c.req.raw, c.env);
});

app.post('/api/integrations/quickbooks/disconnect', async (c) => {
  const { handleQuickBooksDisconnect } = await import('../worker/quickbooks-oauth');
  return handleQuickBooksDisconnect(c.env);
});

// ---- Agent routes (WebSocket + API) ----
app.all('/agents/*', async (c) => {
  const agentResponse = await routeAgentRequest(c.req.raw, c.env);
  if (agentResponse) return agentResponse;
  return c.json({ error: 'Agent not found' }, 404);
});

// ---- API fallback to agent ----
app.all('/api/*', async (c) => {
  const agentResponse = await routeAgentRequest(c.req.raw, c.env);
  if (agentResponse) return agentResponse;
  return c.json({ error: 'Not found' }, 404);
});

// ---- Static assets (React SPA) ----
app.get('/*', (c) => c.env.ASSETS.fetch(c.req.raw));

// ============================================================================
// WORKER EXPORT (single default export — fixes the duplicate export bug)
// ============================================================================

export default {
  /** Handle HTTP requests */
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const response = await app.fetch(request, env, ctx);
    return addSecurityHeaders(response);
  },

  /** Handle queue messages */
  async queue(batch: MessageBatch<QueueMessage>, env: Env): Promise<void> {
    const { default: consumer } = await import('../worker/queue-consumer');
    return consumer.queue(batch, env);
  },
};

export { CarLotAgent };
