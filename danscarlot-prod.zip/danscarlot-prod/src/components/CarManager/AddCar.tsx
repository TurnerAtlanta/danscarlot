import { useNavigate } from 'react-router-dom';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { addCar, type Car } from '../../api';
import { ChevronLeft } from 'lucide-react';

export default function AddCar() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (car: Omit<Car, 'id'>) => addCar(car),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cars'] });
      toast.success('Car added to inventory');
      navigate('/');
    },
    onError: () => toast.error('Failed to add car'),
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);

    const car: Omit<Car, 'id'> = {
      make: String(data.get('make') || ''),
      model: String(data.get('model') || ''),
      year: Number(data.get('year') || 0),
      price: Number(data.get('price') || 0),
      mileage: Number(data.get('mileage') || 0),
      vin: String(data.get('vin') || ''),
      color: String(data.get('color') || '') || undefined,
      image: String(data.get('image') || '') || undefined,
      description: String(data.get('description') || '') || undefined,
      status: 'available',
    };

    mutation.mutate(car);
  };

  return (
    <div className="max-w-xl space-y-5">
      {/* Back nav */}
      <button
        type="button"
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-1 text-sm text-emerald-600 dark:text-emerald-400 font-medium -ml-1"
      >
        <ChevronLeft className="w-4 h-4" />
        Back
      </button>

      <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Add Car</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormSection title="Vehicle Info">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Make" name="make" placeholder="Toyota" required />
            <Field label="Model" name="model" placeholder="Camry" required />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Year" name="year" type="number" placeholder="2020" min={1900} max={new Date().getFullYear() + 2} required />
            <Field label="Price ($)" name="price" type="number" placeholder="18500" min={0} required />
            <Field label="Mileage" name="mileage" type="number" placeholder="32000" min={0} required />
          </div>
          <Field label="VIN" name="vin" placeholder="1HGBH41JXMN109186" required
            inputProps={{ maxLength: 17, pattern: '[A-HJ-NPR-Z0-9]{17}', title: '17-character VIN' }} />
          <Field label="Color" name="color" placeholder="Silver" />
        </FormSection>

        <FormSection title="Listing">
          <Field label="Image URL (optional)" name="image" type="url" placeholder="https://…" />
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
              Description
            </label>
            <textarea
              name="description"
              placeholder="Optional notes about condition, features, etc."
              rows={3}
              className="input resize-none"
            />
          </div>
        </FormSection>

        <div className="flex gap-3 pt-1">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="flex-1 h-12 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={mutation.isPending}
            className="flex-1 h-12 rounded-xl bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-60 transition-colors"
          >
            {mutation.isPending ? 'Saving…' : 'Add Car'}
          </button>
        </div>
      </form>
    </div>
  );
}

// ---- Reusable form components ----

function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
      <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
          {title}
        </span>
      </div>
      <div className="p-4 space-y-3">{children}</div>
    </div>
  );
}

function Field({
  label,
  name,
  type = 'text',
  placeholder,
  required,
  min,
  max,
  inputProps,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  min?: number;
  max?: number;
  inputProps?: React.InputHTMLAttributes<HTMLInputElement>;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={name} className="block text-xs font-medium text-slate-500 dark:text-slate-400">
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        min={min}
        max={max}
        // iOS: numeric keyboards where appropriate
        inputMode={type === 'number' ? 'numeric' : undefined}
        className="input"
        {...inputProps}
      />
    </div>
  );
}
