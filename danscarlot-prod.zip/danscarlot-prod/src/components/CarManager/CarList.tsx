import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { getCars, deleteCar, type Car } from '../../api';
import { Pencil, Trash2, Plus, RefreshCw, Car as CarIcon } from 'lucide-react';

const STATUS_STYLES: Record<string, string> = {
  available: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
  sold: 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400',
  pending: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
};

export default function CarList() {
  const queryClient = useQueryClient();

  const {
    data: cars,
    isLoading,
    isError,
    refetch,
    isFetching,
  } = useQuery<Car[]>({
    queryKey: ['cars'],
    queryFn: getCars,
  });

  const deleteMutation = useMutation({
    mutationFn: deleteCar,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cars'] });
      toast.success('Car removed from inventory');
    },
    onError: () => toast.error('Failed to delete car'),
  });

  const handleDelete = (car: Car) => {
    // iOS-style confirmation
    if (window.confirm(`Remove ${car.year} ${car.make} ${car.model}?`)) {
      deleteMutation.mutate(car.id);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Inventory</h1>
          {cars && (
            <p className="text-xs text-slate-400 mt-0.5">
              {cars.length} vehicle{cars.length !== 1 ? 's' : ''}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => refetch()}
            disabled={isFetching}
            aria-label="Refresh inventory"
            className="inline-flex items-center justify-center w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors disabled:opacity-40"
          >
            <RefreshCw className={`w-4 h-4 ${isFetching ? 'animate-spin' : ''}`} />
          </button>
          <Link
            to="/add"
            className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 h-10 text-sm font-semibold text-white hover:bg-emerald-500 active:bg-emerald-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Car
          </Link>
        </div>
      </div>

      {/* Loading skeleton */}
      {isLoading && (
        <div className="grid gap-3 sm:grid-cols-2">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 animate-pulse">
              <div className="flex gap-3">
                <div className="w-24 h-16 rounded-xl bg-slate-200 dark:bg-slate-800 shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
                  <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                  <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/3" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Error state */}
      {isError && (
        <div className="rounded-2xl border border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/20 p-6 text-center">
          <p className="text-sm text-red-600 dark:text-red-400 font-medium">Failed to load inventory</p>
          <button
            type="button"
            onClick={() => refetch()}
            className="mt-3 text-xs text-red-500 underline"
          >
            Try again
          </button>
        </div>
      )}

      {/* Empty state */}
      {!isLoading && !isError && cars?.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-12 text-center">
          <CarIcon className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-3" />
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">No vehicles yet</p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Add your first car to get started</p>
          <Link
            to="/add"
            className="inline-flex items-center gap-1.5 mt-4 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white"
          >
            <Plus className="w-4 h-4" />
            Add First Car
          </Link>
        </div>
      )}

      {/* Car grid */}
      {!isLoading && !isError && cars && cars.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-2">
          {cars.map((car) => (
            <CarCard
              key={car.id}
              car={car}
              onDelete={handleDelete}
              isDeleting={deleteMutation.isPending && deleteMutation.variables === car.id}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ---- Car Card ----

function CarCard({
  car,
  onDelete,
  isDeleting,
}: {
  car: Car;
  onDelete: (car: Car) => void;
  isDeleting: boolean;
}) {
  const statusClass = STATUS_STYLES[car.status ?? 'available'] ?? STATUS_STYLES.available;

  return (
    <article
      className={`rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden transition-opacity ${isDeleting ? 'opacity-50' : ''}`}
    >
      <div className="flex gap-3 p-3">
        {/* Image */}
        {car.image ? (
          <img
            src={car.image}
            alt={`${car.year} ${car.make} ${car.model}`}
            className="w-28 h-20 object-cover rounded-xl shrink-0 bg-slate-100 dark:bg-slate-800"
            loading="lazy"
          />
        ) : (
          <div className="w-28 h-20 rounded-xl shrink-0 bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
            <CarIcon className="w-8 h-8 text-slate-300 dark:text-slate-700" />
          </div>
        )}

        {/* Details */}
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h2 className="font-semibold text-sm leading-tight text-slate-900 dark:text-slate-100 truncate">
                {car.year} {car.make} {car.model}
              </h2>
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">VIN: {car.vin}</p>
            </div>
            <div className="text-right shrink-0">
              <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                ${(car.price ?? 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-400">
                {(car.mileage ?? 0).toLocaleString()} mi
              </div>
            </div>
          </div>

          {/* Status badge */}
          {car.status && (
            <span className={`inline-block text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full ${statusClass}`}>
              {car.status}
            </span>
          )}

          {car.description && (
            <p className="text-[11px] text-slate-400 dark:text-slate-500 line-clamp-1">
              {car.description}
            </p>
          )}
        </div>
      </div>

      {/* Actions — full-width tap targets (44pt min height) */}
      <div className="flex border-t border-slate-100 dark:border-slate-800 divide-x divide-slate-100 dark:divide-slate-800">
        <Link
          to={`/edit/${car.id}`}
          className="flex-1 inline-flex items-center justify-center gap-1.5 py-3 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          <Pencil className="w-3.5 h-3.5" />
          Edit
        </Link>
        <button
          type="button"
          onClick={() => onDelete(car)}
          disabled={isDeleting}
          className="flex-1 inline-flex items-center justify-center gap-1.5 py-3 text-xs font-medium text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors disabled:opacity-40"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Delete
        </button>
      </div>
    </article>
  );
}
