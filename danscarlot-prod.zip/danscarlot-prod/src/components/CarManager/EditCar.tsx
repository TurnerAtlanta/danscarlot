import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { getCar, updateCar, type Car } from '../../api';
import { ChevronLeft } from 'lucide-react';

export default function EditCar() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: car, isLoading, isError } = useQuery<Car>({
    queryKey: ['cars', id],
    queryFn: () => getCar(id!),
    enabled: !!id,
  });

  const mutation = useMutation({
    mutationFn: (updated: Car) => updateCar(updated),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cars'] });
      toast.success('Car updated');
      navigate('/');
    },
    onError: () => toast.error('Failed to update car'),
  });

  if (!id) return <ErrorState message="Missing car ID." />;
  if (isLoading) return <LoadingState />;
  if (isError || !car) return <ErrorState message="Car not found." />;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);

    mutation.mutate({
      ...car,
      make: String(data.get('make') || ''),
      model: String(data.get('model') || ''),
      year: Number(data.get('year') || 0),
      price: Number(data.get('price') || 0),
      mileage: Number(data.get('mileage') || 0),
      vin: String(data.get('vin') || ''),
      color: String(data.get('color') || '') || undefined,
      image: String(data.get('image') || '') || undefined,
      description: String(data.get('description') || '') || undefined,
    });
  };

  return (
    <div className="max-w-xl space-y-5">
      <button
        type="button"
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-1 text-sm text-emerald-600 dark:text-emerald-400 font-medium -ml-1"
      >
        <ChevronLeft className="w-4 h-4" />
        Back
      </button>

      <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
        Edit {car.year} {car.make} {car.model}
      </h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormSection title="Vehicle Info">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Make" name="make" defaultValue={car.make} required />
            <Field label="Model" name="model" defaultValue={car.model} required />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Year" name="year" type="number" defaultValue={car.year} min={1900} max={new Date().getFullYear() + 2} required />
            <Field label="Price ($)" name="price" type="number" defaultValue={car.price} min={0} required />
            <Field label="Mileage" name="mileage" type="number" defaultValue={car.mileage} min={0} required />
          </div>
          <Field label="VIN" name="vin" defaultValue={car.vin} required
            inputProps={{ maxLength: 17 }} />
          <Field label="Color" name="color" defaultValue={car.color} />
        </FormSection>

        <FormSection title="Listing">
          <Field label="Image URL" name="image" type="url" defaultValue={car.image} />
          <div className="space-y-1.5">
            <label htmlFor="description" className="block text-xs font-medium text-slate-500 dark:text-slate-400">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              defaultValue={car.description}
              rows={3}
              className="input resize-none"
            />
          </div>
        </FormSection>

        <div className="flex gap-3 pt-1">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="flex-1 h-12 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={mutation.isPending}
            className="flex-1 h-12 rounded-xl bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-60 transition-colors"
          >
            {mutation.isPending ? 'Saving…' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
}

// ---- Reusable sub-components (mirrors AddCar) ----

function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
      <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
          {title}
        </span>
      </div>
      <div className="p-4 space-y-3">{children}</div>
    </div>
  );
}

function Field({
  label,
  name,
  type = 'text',
  defaultValue,
  required,
  min,
  max,
  inputProps,
}: {
  label: string;
  name: string;
  type?: string;
  defaultValue?: string | number;
  required?: boolean;
  min?: number;
  max?: number;
  inputProps?: React.InputHTMLAttributes<HTMLInputElement>;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={name} className="block text-xs font-medium text-slate-500 dark:text-slate-400">
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        defaultValue={defaultValue}
        required={required}
        min={min}
        max={max}
        inputMode={type === 'number' ? 'numeric' : undefined}
        className="input"
        {...inputProps}
      />
    </div>
  );
}

function LoadingState() {
  return (
    <div className="max-w-xl space-y-5">
      <div className="h-5 w-16 bg-slate-200 dark:bg-slate-800 rounded animate-pulse" />
      <div className="h-7 w-48 bg-slate-200 dark:bg-slate-800 rounded animate-pulse" />
      <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-4 space-y-3">
        {[1, 2, 3].map((n) => (
          <div key={n} className="h-10 bg-slate-200 dark:bg-slate-800 rounded-xl animate-pulse" />
        ))}
      </div>
    </div>
  );
}

function ErrorState({ message }: { message: string }) {
  const navigate = useNavigate();
  return (
    <div className="text-center py-12">
      <p className="text-sm text-slate-500 dark:text-slate-400">{message}</p>
      <button
        type="button"
        onClick={() => navigate('/')}
        className="mt-4 text-sm text-emerald-600 dark:text-emerald-400 underline"
      >
        Back to inventory
      </button>
    </div>
  );
}
