import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '../ThemeContext';
import { Sun, Moon, Car, PlusCircle, BarChart3 } from 'lucide-react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { darkMode, setDarkMode } = useTheme();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">

        {/* ── Top header ── */}
        <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md"
          style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
          <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between"
            style={{ paddingLeft: 'max(1rem, env(safe-area-inset-left))', paddingRight: 'max(1rem, env(safe-area-inset-right))' }}>

            <Link to="/" className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-semibold tracking-tight">
              <Car className="w-5 h-5" aria-hidden="true" />
              <span>Dan&apos;s Car Lot</span>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden sm:flex items-center gap-1" aria-label="Main navigation">
              <NavLink to="/" active={isActive('/')}>Inventory</NavLink>
              <NavLink to="/add" active={isActive('/add')}>Add Car</NavLink>
              <button
                type="button"
                onClick={() => setDarkMode(!darkMode)}
                aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
                className="ml-2 inline-flex items-center justify-center w-9 h-9 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </nav>

            {/* Mobile dark-mode toggle */}
            <button
              type="button"
              onClick={() => setDarkMode(!darkMode)}
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
              className="sm:hidden inline-flex items-center justify-center w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* ── Main content ── */}
        <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-6 pb-28 sm:pb-8"
          style={{
            paddingLeft: 'max(1rem, env(safe-area-inset-left))',
            paddingRight: 'max(1rem, env(safe-area-inset-right))',
          }}>
          {children}
        </main>

        {/* ── Desktop footer ── */}
        <footer className="hidden sm:block border-t border-slate-200 dark:border-slate-800 text-xs text-slate-400 py-3 text-center">
          © {new Date().getFullYear()} Dan&apos;s Car Lot Manager
        </footer>

        {/* ── iOS-style bottom tab bar (mobile only) ── */}
        <nav
          aria-label="Tab bar"
          className="sm:hidden fixed bottom-0 left-0 right-0 z-50 border-t border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md flex items-stretch"
          style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
        >
          <TabBarItem to="/" icon={<Car className="w-5 h-5" />} label="Inventory" active={isActive('/')} />
          <TabBarItem to="/add" icon={<PlusCircle className="w-5 h-5" />} label="Add Car" active={isActive('/add')} />
          {/* Placeholder for Analytics — easy to wire up later */}
          <TabBarItem to="/analytics" icon={<BarChart3 className="w-5 h-5" />} label="Analytics" active={isActive('/analytics')} />
        </nav>
      </div>
    </div>
  );
}

// ---- Sub-components ----

function NavLink({ to, active, children }: { to: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
        active
          ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400'
          : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
      }`}
    >
      {children}
    </Link>
  );
}

function TabBarItem({
  to,
  icon,
  label,
  active,
}: {
  to: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={`flex-1 flex flex-col items-center justify-center gap-0.5 py-2 min-h-[49px] transition-colors ${
        active
          ? 'text-emerald-600 dark:text-emerald-400'
          : 'text-slate-500 dark:text-slate-400'
      }`}
      aria-current={active ? 'page' : undefined}
    >
      {icon}
      <span className="text-[10px] font-medium">{label}</span>
    </Link>
  );
}
