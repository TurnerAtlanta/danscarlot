/**
 * src/api.ts — API client for Dan's Car Lot
 *
 * Uses relative URLs so the same build works on localhost AND production
 * (no hardcoded domain). The Worker routes `/api/*` to the CarLotAgent.
 *
 * Fix: endpoints updated from `/api/cars` → `/api/vehicles` to match the worker.
 */

// Relative base — works on localhost:5173 (Vite proxy) and danscarlot.turneratlanta.com
const API_BASE = '/api';

// ---- Types ----

export interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  /** Sale price (maps to `saleprice` in DB) */
  price: number;
  mileage: number;
  /** Primary image URL */
  image?: string;
  vin: string;
  description?: string;
  status?: string;
  color?: string;
  bodystyle?: string;
  transmission?: string;
  fueltype?: string;
  location?: string;
  purchaseprice?: number;
  purchasedate?: string;
}

export interface Analytics {
  totalRevenue: number;
  totalCost: number;
  profit: number;
  margin: number;
  soldCount: number;
  inventoryCount: number;
  avgProfitPerVehicle: number;
}

// ---- Helpers ----

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text().catch(() => res.statusText);
    throw new Error(`API error ${res.status}: ${body}`);
  }
  return res.json() as Promise<T>;
}

// ---- Vehicles / Cars ----

export async function getCars(): Promise<Car[]> {
  return handleResponse<Car[]>(await fetch(`${API_BASE}/vehicles`));
}

export async function getCar(id: string): Promise<Car> {
  return handleResponse<Car>(await fetch(`${API_BASE}/vehicles/${encodeURIComponent(id)}`));
}

export async function addCar(car: Omit<Car, 'id'>): Promise<Car> {
  return handleResponse<Car>(
    await fetch(`${API_BASE}/vehicles`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...car, id: crypto.randomUUID() }),
    })
  );
}

export async function updateCar(car: Car): Promise<Car> {
  return handleResponse<Car>(
    await fetch(`${API_BASE}/vehicles/${encodeURIComponent(car.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(car),
    })
  );
}

export async function deleteCar(id: string): Promise<void> {
  await handleResponse<{ success: boolean }>(
    await fetch(`${API_BASE}/vehicles/${encodeURIComponent(id)}`, { method: 'DELETE' })
  );
}

// ---- Analytics ----

export async function getAnalytics(): Promise<Analytics> {
  return handleResponse<Analytics>(await fetch(`${API_BASE}/analytics`));
}
