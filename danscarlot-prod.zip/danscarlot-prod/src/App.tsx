import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import CarList from './components/CarManager/CarList';
import AddCar from './components/CarManager/AddCar';
import EditCar from './components/CarManager/EditCar';
import { ThemeProvider } from './ThemeContext';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Stale time: 30s for inventory (real-time enough without hammering the API)
      staleTime: 30_000,
      retry: 2,
    },
  },
});

function AppContent() {
  const [darkMode, setDarkMode] = useState(false);

  // Initialise from localStorage or system preference
  useEffect(() => {
    const stored = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setDarkMode(stored === 'dark' || (!stored && prefersDark));
  }, []);

  // Apply / persist
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    // Update theme-color meta for iOS status bar
    const metaTheme = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.content = darkMode ? '#0f172a' : '#10b981';
    }
    localStorage.setItem('theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  return (
    <ThemeProvider darkMode={darkMode} setDarkMode={setDarkMode}>
      <Layout>
        <Routes>
          <Route path="/" element={<CarList />} />
          <Route path="/add" element={<AddCar />} />
          <Route path="/edit/:id" element={<EditCar />} />
        </Routes>
        <Toaster
          position="top-center"
          toastOptions={{
            // Respect iOS safe areas
            style: { marginTop: 'env(safe-area-inset-top, 0px)' },
          }}
        />
      </Layout>
    </ThemeProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </QueryClientProvider>
  );
}
