# Dan's Car Lot Manager — v3

A full-stack car lot inventory management PWA built on **Cloudflare Workers**, optimised for iPhone.

## Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + TypeScript + Vite |
| Styling | Tailwind CSS (SF Pro system fonts, Apple HIG) |
| PWA | vite-plugin-pwa + Workbox (offline-first) |
| Worker | Hono + Cloudflare Workers |
| Database | Durable Objects SQLite (CarLotAgent) |
| KV | Cloudflare KV (auth + integrations tokens) |
| Queues | Cloudflare Queues (async DMS + QB sync) |
| CI/CD | GitHub Actions → `wrangler deploy` |

---

## First-time setup

### 1. Install dependencies

```bash
npm install
```

### 2. Create KV namespaces

```bash
# Auth KV
npx wrangler kv namespace create AUTH_KV
npx wrangler kv namespace create AUTH_KV --preview

# Integrations KV (QuickBooks tokens, etc.)
npx wrangler kv namespace create INTEGRATIONS_KV
npx wrangler kv namespace create INTEGRATIONS_KV --preview
```

Copy the returned IDs into `wrangler.jsonc` under `kv_namespaces`.

### 3. Create the queue

```bash
npx wrangler queues create sync-queue
npx wrangler queues create sync-dlq
```

### 4. Set secrets

Never commit these — use `wrangler secret put`:

```bash
npx wrangler secret put WAYNE_REEVES_API_KEY
npx wrangler secret put QUICKBOOKS_CLIENT_ID
npx wrangler secret put QUICKBOOKS_CLIENT_SECRET
npx wrangler secret put QUICKBOOKS_REALM_ID   # Your QBO Company ID
npx wrangler secret put CARGURUS_API_KEY       # Optional
```

### 5. Add GitHub repository secrets

In GitHub → Settings → Secrets → Actions, add:

- `CLOUDFLARE_API_TOKEN` — create at dash.cloudflare.com/profile/api-tokens (use "Edit Cloudflare Workers" template)
- `CLOUDFLARE_ACCOUNT_ID` — found in the Workers dashboard right sidebar

---

## Development

Run both the Vite dev server and the Wrangler worker locally:

```bash
npm run dev:all
```

- Vite: `http://localhost:5173` (hot reload)
- Worker: `http://localhost:8787`
- Vite proxies `/api/*` and `/agents/*` to the worker automatically

---

## Build & Deploy

```bash
# Build React app + deploy to production
npm run deploy

# Deploy to staging only
npm run deploy:staging
```

Or just push to `main` — GitHub Actions will handle it automatically.

---

## PWA / iPhone Setup

The app is a full Progressive Web App optimised for iPhone:

- **Home screen install**: tap Share → "Add to Home Screen"
- **Offline**: inventory is cached by the service worker — works without internet
- **Safe areas**: content respects the Dynamic Island / notch via `env(safe-area-inset-*)`
- **Tap targets**: all interactive elements are ≥ 44pt (Apple HIG minimum)
- **No zoom on focus**: inputs use `font-size: 16px` to prevent iOS auto-zoom
- **Status bar**: transparent, blends with the header (`black-translucent`)
- **Theme color**: switches dynamically between light/dark mode

### Splash screens

Generate splash screen PNGs using [progressier.com](https://progressier.com/pwa-icons-and-splash-screen-generator) and place them in `public/splash/`:

```
public/splash/
  splash-430x932.png   # iPhone 15 Pro Max
  splash-390x844.png   # iPhone 15 / 14
  splash-375x667.png   # iPhone SE
  splash-1024x1366.png # iPad Pro 12.9"
```

### Icons

Place these in `public/`:

- `favicon.ico` (32×32)
- `icon-192.png` (192×192)
- `icon-512.png` (512×512)
- `apple-touch-icon.png` (180×180 — **no rounded corners**, iOS applies them)
- `icon-152.png` (152×152 — iPad)
- `icon-167.png` (167×167 — iPad Pro)

---

## Architecture

```
Browser / iPhone PWA
        │
        ▼
Cloudflare Worker (src/index.ts)
   ├── Hono router
   ├── CORS + security headers
   ├── /api/*  ──────────────▶ CarLotAgent (Durable Object)
   │                               ├── SQLite: vehicles, tasks, services, comments
   │                               ├── WebSocket broadcast
   │                               └── SYNC_QUEUE.send() on sale/service
   ├── /agents/* ──────────▶ Agent WebSocket hub
   ├── /api/integrations/quickbooks/* ──▶ QB OAuth flow
   └── /* ─────────────────▶ ASSETS (React SPA)

Cloudflare Queue (sync-queue)
   └── worker/queue-consumer.ts
         ├── vehicle_sync  ──▶ Wayne Reeves DMS API
         ├── expense_sync  ──▶ QuickBooks Online API
         └── quickbooks_auth_refresh ──▶ QB token refresh
```

---

## Bug fixes vs. v2

| Bug | Fix |
|-----|-----|
| `import Hono from 'hono'` (default import) | `import { Hono } from 'hono'` (named export) |
| `let WebSocketMessage` (undeclared variable) | `let data: WebSocketMessage` |
| Duplicate `export default` | Single unified export with `queue` handler merged in |
| `connection.accept()` (legacy WebSocket API) | Removed — Agent base class handles via `ctx.acceptWebSocket` |
| `/api/cars` in `api.ts` vs `/api/vehicles` in worker | Updated `api.ts` to use `/api/vehicles` |
| Hardcoded `https://api.danscarlot.turneratlanta.com` in `api.ts` | Relative `/api` URLs (works on localhost + prod) |
| `wrangler.toml` pointing `assets` at `./public/` | `wrangler.jsonc` pointing `assets` at `./dist/` (Vite output) |
| No PWA plugin in `vite.config.ts` | `vite-plugin-pwa` added with Workbox strategies |
| No `<BrowserRouter>` wrapper | Added in `App.tsx` |
| No security headers | Added via Hono `secureHeaders()` + custom CSP |
| QuickBooks import path broken | Fixed to `../worker/quickbooks-oauth` |
| No iPhone safe area support | `viewport-fit=cover` + `env(safe-area-inset-*)` throughout |
| Inputs cause zoom on iOS | All inputs `font-size: 16px` |
| Tap targets < 44pt | All buttons/links now `min-height: 44px` (⌘ iOS HIG) |
