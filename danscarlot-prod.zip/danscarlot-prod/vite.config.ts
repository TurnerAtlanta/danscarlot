import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),

    VitePWA({
      // Use 'autoUpdate' so the SW updates automatically in production.
      // Switch to 'prompt' if you want to show "New version available" UI.
      registerType: 'autoUpdate',

      // Don't generate a separate src/sw file — use our configured workbox strategies
      injectRegister: null, // We register manually in main.tsx

      // Workbox config: precache all build assets + runtime cache API responses
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],

        // Runtime caching strategies
        runtimeCaching: [
          {
            // Cache the inventory API with a network-first strategy (fresh data,
            // falls back to cache when offline)
            urlPattern: /^\/api\/vehicles/,
            handler: 'NetworkFirst',
            options: {
              cacheName: 'api-vehicles',
              expiration: {
                maxEntries: 50,
                maxAgeSeconds: 60 * 5, // 5 minutes
              },
              networkTimeoutSeconds: 10,
              cacheableResponse: { statuses: [0, 200] },
            },
          },
          {
            // Cache vehicle images with a cache-first strategy (images rarely change)
            urlPattern: /\.(png|jpg|jpeg|webp|gif|svg)$/,
            handler: 'CacheFirst',
            options: {
              cacheName: 'images',
              expiration: {
                maxEntries: 100,
                maxAgeSeconds: 60 * 60 * 24 * 30, // 30 days
              },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
        ],
      },

      // manifest is in public/ — don't let the plugin re-generate it
      manifest: false,
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon-*.png'],
    }),
  ],

  // ── Development proxy ──────────────────────────────────────────────────────
  // In dev, Vite serves on :5173 but the worker runs on :8787.
  // This proxy forwards /api/* so `api.ts` can use relative URLs.
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8787',
        changeOrigin: true,
      },
      '/agents': {
        target: 'ws://localhost:8787',
        ws: true,
        changeOrigin: true,
      },
    },
  },

  // ── Build ──────────────────────────────────────────────────────────────────
  build: {
    outDir: 'dist',
    // Generate source maps for production debugging via Cloudflare Workers
    sourcemap: true,
    rollupOptions: {
      output: {
        // Split vendor libraries into a separate chunk for better caching
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          query: ['@tanstack/react-query'],
        },
      },
    },
  },
});
